
'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';

import {
  institutionApi,
  type Department,
  type AcademicYearOption,
  type AcademicYearCreatePayload,
  type AcademicPeriod,
  type AcademicPeriodCreatePayload,
  type AcademicSession,
  type AcademicSessionCreatePayload,
  type AcademicSessionStatus,
  type AcademicYearStatus,
  type Batch,
  type Section,
} from '@/lib/api';

// ============================================================
// TYPES AND CONSTANTS
// ============================================================

type Tab = 'structure' | 'sessions' | 'sections';

interface SessionForm {
  department_id: string;
  academic_year_id: string;
  academic_period_id: string;
  semester_number: string;
  start_date: string;
  end_date: string;
  status: AcademicSessionStatus;
}

interface SectionForm {
  name: string;
  capacity_informational: string;
}

const emptyYearForm: AcademicYearCreatePayload = {
  name: '',
  start_date: '',
  end_date: '',
  status: 'planned',
};

const emptyPeriodForm: AcademicPeriodCreatePayload = {
  name: '',
  start_date: '',
  end_date: '',
  status: 'planned',
};

const emptySessionForm: SessionForm = {
  department_id: '',
  academic_year_id: '',
  academic_period_id: '',
  semester_number: '',
  start_date: '',
  end_date: '',
  status: 'planned',
};

const emptySectionForm: SectionForm = {
  name: '',
  capacity_informational: '60',
};

const inputClass =
  'w-full rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] px-4 py-3 text-sm text-[var(--foreground)] outline-none transition focus:border-cyan-500 disabled:cursor-not-allowed disabled:opacity-50';

// ============================================================
// HELPERS
// ============================================================

function formatDate(value?: string) {
  if (!value) return '—';

  return new Date(`${value}T00:00:00`).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

function statusClass(status: string) {
  switch (status) {
    case 'active':
      return 'border-emerald-500/20 bg-emerald-500/10 text-emerald-600';
    case 'completed':
      return 'border-blue-500/20 bg-blue-500/10 text-blue-600';
    case 'cancelled':
      return 'border-red-500/20 bg-red-500/10 text-red-600';
    default:
      return 'border-amber-500/20 bg-amber-500/10 text-amber-600';
  }
}

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

// ============================================================
// REUSABLE COMPONENTS
// ============================================================

function Field({
  label,
  hint,
  example,
  children,
}: {
  label: string;
  hint?: string;
  example?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-semibold">
        {label}
      </label>

      {children}

      {hint && (
        <p className="mt-1.5 text-xs leading-5 text-slate-500">
          {hint}
        </p>
      )}

      {example && (
        <p className="mt-1 text-xs text-cyan-600">
          Example: {example}
        </p>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  return (
    <span
      className={`inline-flex rounded-full border px-3 py-1 text-xs font-semibold capitalize ${statusClass(status)}`}
    >
      {status}
    </span>
  );
}

function FormError({ message }: { message: string }) {
  return (
    <div
      role="alert"
      className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-600"
    >
      {message}
    </div>
  );
}

function InfoBox({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4">
      <p className="text-sm font-semibold text-cyan-700 dark:text-cyan-400">
        {title}
      </p>

      <div className="mt-1 text-xs leading-5 text-slate-600 dark:text-slate-400">
        {children}
      </div>
    </div>
  );
}

function Modal({
  title,
  description,
  onClose,
  submitting,
  children,
}: {
  title: string;
  description: string;
  onClose: () => void;
  submitting: boolean;
  children: React.ReactNode;
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/60 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (
          event.target === event.currentTarget &&
          !submitting
        ) {
          onClose();
        }
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        className="my-auto max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-6 shadow-2xl sm:p-8"
      >
        <div className="mb-6 flex items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold">{title}</h2>
            <p className="mt-1 text-sm text-slate-500">
              {description}
            </p>
          </div>

          <button
            type="button"
            disabled={submitting}
            onClick={onClose}
            aria-label="Close dialog"
            className="rounded-lg px-2 py-1 text-xl text-slate-500 hover:bg-black/5 disabled:opacity-50 dark:hover:bg-white/10"
          >
            ×
          </button>
        </div>

        {children}
      </div>
    </div>
  );
}

function ModalActions({
  onCancel,
  submitting,
  submitLabel,
}: {
  onCancel: () => void;
  submitting: boolean;
  submitLabel: string;
}) {
  return (
    <div className="flex flex-col-reverse gap-3 border-t border-[var(--border-color)] pt-5 sm:flex-row sm:justify-end">
      <button
        type="button"
        disabled={submitting}
        onClick={onCancel}
        className="rounded-xl border border-[var(--border-color)] px-5 py-3 text-sm font-semibold hover:bg-black/5 disabled:opacity-50 dark:hover:bg-white/5"
      >
        Cancel
      </button>

      <button
        type="submit"
        disabled={submitting}
        className="rounded-xl bg-cyan-600 px-5 py-3 text-sm font-semibold text-white hover:bg-cyan-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {submitting ? 'Saving...' : submitLabel}
      </button>
    </div>
  );
}

// ============================================================
// MAIN COMPONENT
// ============================================================

export default function LiveAcademicsClient() {
  // ----------------------------------------------------------
  // NAVIGATION
  // ----------------------------------------------------------

  const [activeTab, setActiveTab] = useState<Tab>('structure');

  // ----------------------------------------------------------
  // DATABASE DATA
  // ----------------------------------------------------------

  const [departments, setDepartments] = useState<Department[]>([]);
  const [academicYears, setAcademicYears] = useState<AcademicYearOption[]>([]);
  const [periods, setPeriods] = useState<AcademicPeriod[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [sections, setSections] = useState<Section[]>([]);

  const [periodNames, setPeriodNames] = useState<Record<string, string>>({});

  // ----------------------------------------------------------
  // PAGE SELECTIONS
  // ----------------------------------------------------------

  const [selectedYearId, setSelectedYearId] = useState('');
  const [selectedPeriodId, setSelectedPeriodId] = useState('');
  const [sessionYearFilter, setSessionYearFilter] = useState('all');

  const [selectedBatchId, setSelectedBatchId] = useState('');

  // ----------------------------------------------------------
  // PAGE STATES
  // ----------------------------------------------------------

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [pageError, setPageError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // ----------------------------------------------------------
  // MODAL STATES
  // ----------------------------------------------------------

  const [showYearForm, setShowYearForm] = useState(false);
  const [showPeriodForm, setShowPeriodForm] = useState(false);
  const [showSessionForm, setShowSessionForm] = useState(false);
  const [showSectionForm, setShowSectionForm] = useState(false);

  // ----------------------------------------------------------
  // SUBMISSION STATES
  // ----------------------------------------------------------

  const [submitting, setSubmitting] = useState(false);
  const [sectionSubmitting, setSectionSubmitting] = useState(false);

  const [formError, setFormError] = useState('');
  const [sectionError, setSectionError] = useState('');

  // ----------------------------------------------------------
  // FORM STATES
  // ----------------------------------------------------------

  const [yearForm, setYearForm] =
    useState<AcademicYearCreatePayload>(emptyYearForm);

  const [periodForm, setPeriodForm] =
    useState<AcademicPeriodCreatePayload>(emptyPeriodForm);

  const [sessionForm, setSessionForm] =
    useState<SessionForm>(emptySessionForm);

  const [sectionForm, setSectionForm] =
    useState<SectionForm>(emptySectionForm);

  const [editingSection, setEditingSection] =
    useState<Section | null>(null);

  // ----------------------------------------------------------
  // DERIVED RECORDS
  // ----------------------------------------------------------

  const selectedYear = academicYears.find(
    (year) => year.id === selectedYearId
  );

  const selectedPeriod = periods.find(
    (period) => period.id === selectedPeriodId
  );

  const sessionYear = academicYears.find(
    (year) => year.id === sessionForm.academic_year_id
  );

  const sessionPeriod = periods.find(
    (period) => period.id === sessionForm.academic_period_id
  );

  const selectedDepartment = departments.find(
    (department) => department.id === sessionForm.department_id
  );

  const selectedBatch = batches.find(
    (batch) => batch.id === selectedBatchId
  );

  const batchSections = useMemo(
    () =>
      sections.filter(
        (section) => section.batch_id === selectedBatchId
      ),
    [sections, selectedBatchId]
  );

  // ----------------------------------------------------------
  // LOAD ALL DATA
  // ----------------------------------------------------------

  const loadData = useCallback(async (refresh = false) => {
    if (refresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setPageError('');

    try {
      const [
        departmentData,
        yearData,
        batchData,
        sessionData,
        sectionData,
      ] = await Promise.all([
        institutionApi.getDepartments(),
        institutionApi.getAcademicYears(),
        institutionApi.getBatches(),
        institutionApi.getAcademicSessions(),
        institutionApi.getSections(),
      ]);

      setDepartments(departmentData);
      setAcademicYears(yearData);
      setBatches(batchData);
      setSessions(sessionData);
      setSections(sectionData);

      setSelectedYearId((current) => {
        if (current && yearData.some((year) => year.id === current)) {
          return current;
        }

        return yearData[0]?.id ?? '';
      });

      setSelectedBatchId((current) => {
        if (current && batchData.some((batch) => batch.id === current)) {
          return current;
        }

        return batchData[0]?.id ?? '';
      });

      setSessionYearFilter((current) => {
        if (
          current !== 'all' &&
          !yearData.some((year) => year.id === current)
        ) {
          return 'all';
        }

        return current;
      });

      const periodResults = await Promise.all(
        yearData.map(async (year) => {
          try {
            return await institutionApi.getAcademicPeriods(year.id);
          } catch {
            return [];
          }
        })
      );

      const periodLookup: Record<string, string> = {};

      periodResults.flat().forEach((period) => {
        periodLookup[period.id] = period.name;
      });

      setPeriodNames(periodLookup);
    } catch (error) {
      setPageError(
        getErrorMessage(error, 'Unable to load academic records.')
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // ----------------------------------------------------------
  // INITIAL LOAD
  // ----------------------------------------------------------

  useEffect(() => {
    void loadData();
  }, [loadData]);

  // ----------------------------------------------------------
  // LOAD PERIODS WHEN YEAR CHANGES
  // ----------------------------------------------------------

  useEffect(() => {
    let cancelled = false;

    async function fetchPeriods() {
      if (!selectedYearId) {
        setPeriods([]);
        setSelectedPeriodId('');
        return;
      }

      try {
        const data = await institutionApi.getAcademicPeriods(
          selectedYearId
        );

        if (cancelled) return;

        setPeriods(data);

        setSelectedPeriodId((current) => {
          if (current && data.some((period) => period.id === current)) {
            return current;
          }

          return data[0]?.id ?? '';
        });
      } catch (error) {
        if (cancelled) return;

        setPeriods([]);
        setSelectedPeriodId('');

        setPageError(
          getErrorMessage(error, 'Unable to load annual periods.')
        );
      }
    }

    void fetchPeriods();

    return () => {
      cancelled = true;
    };
  }, [selectedYearId]);

  // ----------------------------------------------------------
  // SESSION FILTERS AND CALCULATIONS
  // ----------------------------------------------------------

  const filteredSessions = useMemo(() => {
    if (sessionYearFilter === 'all') return sessions;

    return sessions.filter(
      (session) => session.academic_year_id === sessionYearFilter
    );
  }, [sessions, sessionYearFilter]);

  const sessionPeriodIndex = periods.findIndex(
    (period) => period.id === sessionForm.academic_period_id
  );

  const availableSemesters =
    sessionPeriodIndex >= 0
      ? [
          sessionPeriodIndex * 2 + 1,
          sessionPeriodIndex * 2 + 2,
        ]
      : [];

  const activeSessions = sessions.filter(
    (session) => session.status === 'active'
  ).length;

  const plannedSessions = sessions.filter(
    (session) => session.status === 'planned'
  ).length;

  const completedSessions = sessions.filter(
    (session) => session.status === 'completed'
  ).length;

  const cancelledSessions = sessions.filter(
    (session) => session.status === 'cancelled'
  ).length;

  const batchPreview =
    selectedDepartment && sessionYear
      ? `${selectedDepartment.code} ${sessionYear.start_date.slice(0, 4)}-${sessionYear.end_date.slice(2, 4)}`
      : '';

  // ----------------------------------------------------------
  // NOTIFICATIONS
  // ----------------------------------------------------------

  function notify(message: string) {
    setSuccessMessage(message);
    window.setTimeout(() => setSuccessMessage(''), 4500);
  }

  // ----------------------------------------------------------
  // MODAL CONTROLS
  // ----------------------------------------------------------

  function closeForms() {
    if (submitting) return;

    setShowYearForm(false);
    setShowPeriodForm(false);
    setShowSessionForm(false);
    setFormError('');
  }

  function openYearForm() {
    setYearForm(emptyYearForm);
    setFormError('');
    setShowYearForm(true);
  }

  function openPeriodForm() {
    setPeriodForm(emptyPeriodForm);
    setFormError('');
    setShowPeriodForm(true);
  }

  function openSessionForm() {
    setSessionForm({
      ...emptySessionForm,
      academic_year_id: selectedYearId,
      academic_period_id: selectedPeriodId,
    });

    setFormError('');
    setShowSessionForm(true);
  }

  // ----------------------------------------------------------
  // CREATE ACADEMIC YEAR
  // ----------------------------------------------------------

  async function handleCreateYear(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();
    setFormError('');

    const name = yearForm.name.trim();

    if (!/^\d{4}-(\d{2}|\d{4})$/.test(name)) {
      setFormError(
        'Use the format YYYY-YY or YYYY-YYYY. Example: 2023-27.'
      );
      return;
    }

    if (
      !yearForm.start_date ||
      !yearForm.end_date ||
      yearForm.end_date <= yearForm.start_date
    ) {
      setFormError('End date must be later than start date.');
      return;
    }

    setSubmitting(true);

    try {
      const created = await institutionApi.createAcademicYear({
        ...yearForm,
        name,
      });

      await loadData(true);

      setSelectedYearId(created.id);
      setSelectedPeriodId('');
      setYearForm(emptyYearForm);
      setShowYearForm(false);
      setActiveTab('structure');

      notify(`Academic year ${created.name} created successfully.`);
    } catch (error) {
      setFormError(
        getErrorMessage(error, 'Unable to create academic year.')
      );
    } finally {
      setSubmitting(false);
    }
  }

  // ----------------------------------------------------------
  // CREATE ANNUAL PERIOD
  // ----------------------------------------------------------

  async function handleCreatePeriod(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();
    setFormError('');

    if (!selectedYear) {
      setFormError('Select an academic year first.');
      return;
    }

    if (
      !periodForm.name.trim() ||
      !periodForm.start_date ||
      !periodForm.end_date
    ) {
      setFormError('Complete all annual period fields.');
      return;
    }

    if (periodForm.end_date <= periodForm.start_date) {
      setFormError('End date must be after start date.');
      return;
    }

    if (
      periodForm.start_date < selectedYear.start_date ||
      periodForm.end_date > selectedYear.end_date
    ) {
      setFormError(
        'Annual period dates must be within the parent academic year.'
      );
      return;
    }

    const overlaps = periods.some(
      (period) =>
        periodForm.start_date <= period.end_date &&
        periodForm.end_date >= period.start_date
    );

    if (overlaps) {
      setFormError('This annual period overlaps an existing period.');
      return;
    }

    setSubmitting(true);

    try {
      const created = await institutionApi.createAcademicPeriod(
        selectedYear.id,
        {
          ...periodForm,
          name: periodForm.name.trim(),
        }
      );

      setPeriods((previous) =>
        [...previous, created].sort((a, b) =>
          a.start_date.localeCompare(b.start_date)
        )
      );

      setPeriodNames((previous) => ({
        ...previous,
        [created.id]: created.name,
      }));

      setSelectedPeriodId(created.id);
      setPeriodForm(emptyPeriodForm);
      setShowPeriodForm(false);

      notify(`Annual period ${created.name} created successfully.`);
    } catch (error) {
      setFormError(
        getErrorMessage(error, 'Unable to create annual period.')
      );
    } finally {
      setSubmitting(false);
    }
  }

  // ----------------------------------------------------------
  // CREATE SEMESTER SESSION
  // ----------------------------------------------------------

  async function handleCreateSession(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();
    setFormError('');

    if (!sessionForm.department_id) {
      setFormError('Select a department.');
      return;
    }

    if (!sessionYear || !sessionPeriod) {
      setFormError('Select an academic year and annual period.');
      return;
    }

    const semesterNumber = Number(sessionForm.semester_number);

    if (!availableSemesters.includes(semesterNumber)) {
      setFormError(
        'Select a semester that belongs to the chosen annual period.'
      );
      return;
    }

    if (
      !sessionForm.start_date ||
      !sessionForm.end_date ||
      sessionForm.end_date <= sessionForm.start_date
    ) {
      setFormError('Enter valid semester session dates.');
      return;
    }

    if (
      sessionForm.start_date < sessionPeriod.start_date ||
      sessionForm.end_date > sessionPeriod.end_date
    ) {
      setFormError(
        'Semester dates must fall within the selected annual period.'
      );
      return;
    }

    const matchingBatch = batches.find(
      (batch) => batch.name === batchPreview
    );

    if (
      matchingBatch &&
      sessions.some(
        (session) =>
          session.batch_id === matchingBatch.id &&
          session.academic_year_id === sessionYear.id &&
          session.semester_number === semesterNumber
      )
    ) {
      setFormError(
        'This semester already exists for this batch and academic year.'
      );
      return;
    }

    const payload: AcademicSessionCreatePayload = {
      department_id: sessionForm.department_id,
      academic_year_id: sessionYear.id,
      academic_period_id: sessionPeriod.id,
      semester_number: semesterNumber,
      start_date: sessionForm.start_date,
      end_date: sessionForm.end_date,
      status: sessionForm.status,
    };

    setSubmitting(true);

    try {
      await institutionApi.createAcademicSession(payload);

      setShowSessionForm(false);
      setSessionForm(emptySessionForm);

      await loadData(true);

      notify(
        `Semester ${semesterNumber} session created successfully.`
      );
    } catch (error) {
      setFormError(
        getErrorMessage(error, 'Unable to create semester session.')
      );
    } finally {
      setSubmitting(false);
    }
  }

  // ----------------------------------------------------------
  // SECTION MANAGEMENT
  // ----------------------------------------------------------

  function openCreateSectionForm() {
    if (!selectedBatchId) {
      notify('Select a batch first.');
      return;
    }

    setEditingSection(null);
    setSectionForm(emptySectionForm);
    setSectionError('');
    setShowSectionForm(true);
  }

  function openEditSectionForm(section: Section) {
    setEditingSection(section);

    setSectionForm({
      name: section.name,
      capacity_informational: String(
        section.capacity_informational
      ),
    });

    setSectionError('');
    setShowSectionForm(true);
  }

  function closeSectionForm() {
    if (sectionSubmitting) return;

    setShowSectionForm(false);
    setEditingSection(null);
    setSectionForm(emptySectionForm);
    setSectionError('');
  }

  async function handleSaveSection(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();
    setSectionError('');

    const name = sectionForm.name.trim().toUpperCase();
    const capacity = Number(sectionForm.capacity_informational);

    if (!name) {
      setSectionError('Section name is required.');
      return;
    }

    if (!Number.isInteger(capacity) || capacity < 1) {
      setSectionError('Capacity must be a positive whole number.');
      return;
    }

    if (!editingSection && !selectedBatchId) {
      setSectionError('Select a batch before creating a section.');
      return;
    }

    setSectionSubmitting(true);

    try {
      if (editingSection) {
        const updated = await institutionApi.updateSection(
          editingSection.id,
          {
            name,
            capacity_informational: capacity,
          }
        );

        setSections((previous) =>
          previous.map((section) =>
            section.id === updated.id ? updated : section
          )
        );

        notify(`Section ${updated.name} updated successfully.`);
      } else {
        const created = await institutionApi.createSection({
          batch_id: selectedBatchId,
          name,
          capacity_informational: capacity,
        });

        setSections((previous) =>
          [...previous, created].sort((a, b) =>
            a.name.localeCompare(b.name)
          )
        );

        notify(`Section ${created.name} created successfully.`);
      }

      setShowSectionForm(false);
      setEditingSection(null);
      setSectionForm(emptySectionForm);
    } catch (error) {
      setSectionError(
        getErrorMessage(error, 'Unable to save section.')
      );
    } finally {
      setSectionSubmitting(false);
    }
  }

  // ----------------------------------------------------------
  // DISPLAY HELPERS
  // ----------------------------------------------------------

  function getBatchName(batchId: string) {
    return batches.find((batch) => batch.id === batchId)?.name
      ?? 'Unknown batch';
  }

  function getYearName(yearId: string) {
    return academicYears.find((year) => year.id === yearId)?.name
      ?? 'Unknown year';
  }

  function getPeriodName(periodId?: string | null) {
    if (!periodId) return 'Not mapped';

    return periodNames[periodId] ?? 'Not mapped';
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'structure', label: 'Academic Structure' },
    { id: 'sessions', label: 'Semester Sessions' },
    { id: 'sections', label: 'Sections' },
  ];

  // ==========================================================
  // RENDER
  // ==========================================================

  return (
    <div className="space-y-7 text-[var(--foreground)]">

      {/* HEADER */}

      <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
            Institution / Administration
          </p>

          <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
            Academic Management
          </h1>

          <p className="mt-2 text-sm text-slate-500">
            Manage academic years, annual periods, semester sessions and sections.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void loadData(true)}
            disabled={refreshing}
            className="rounded-xl border border-[var(--border-color)] px-4 py-2.5 text-sm font-medium hover:bg-black/5 disabled:opacity-50 dark:hover:bg-white/5"
          >
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </button>

          <button
            type="button"
            onClick={openYearForm}
            className="rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700"
          >
            + Create Academic Year
          </button>
        </div>
      </header>

      {/* NOTIFICATIONS */}

      {successMessage && (
        <div
          role="status"
          className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-600"
        >
          {successMessage}
        </div>
      )}

      {pageError && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4">
          <p className="text-sm font-semibold text-red-600">
            Unable to load academic data
          </p>

          <p className="mt-1 text-sm text-red-600">{pageError}</p>

          <button
            type="button"
            onClick={() => void loadData()}
            className="mt-3 text-sm font-semibold text-red-600 underline"
          >
            Retry
          </button>
        </div>
      )}

      {/* SUMMARY CARDS */}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['Academic Years', academicYears.length],
          ['Annual Periods', periods.length],
          ['Semester Sessions', sessions.length],
          ['Active Sessions', activeSessions],
        ].map(([label, value]) => (
          <div
            key={label}
            className="rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-5"
          >
            <p className="text-sm text-slate-500">{label}</p>

            <p className="mt-3 text-3xl font-bold">
              {loading ? '—' : value}
            </p>
          </div>
        ))}
      </div>

      {/* TABS */}

      <div className="flex gap-6 overflow-x-auto border-b border-[var(--border-color)]">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`whitespace-nowrap border-b-2 pb-3 text-sm font-semibold ${
              activeTab === tab.id
                ? 'border-cyan-500 text-cyan-600'
                : 'border-transparent text-slate-500 hover:text-[var(--foreground)]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-12 text-center text-sm text-slate-500">
          Loading academic records...
        </div>
      ) : (
        <>
          {/* ==================================================
              ACADEMIC STRUCTURE
          ================================================== */}

          {activeTab === 'structure' && (
            <section className="space-y-5">

              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-lg font-bold">Academic Years</h2>

                  <p className="mt-1 text-sm text-slate-500">
                    Select a parent academic year to manage its annual periods.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={openPeriodForm}
                  disabled={!selectedYear}
                  className="rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700 disabled:opacity-40"
                >
                  + Add Annual Period
                </button>
              </div>

              <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-5">
                <Field
                  label="Select Academic Year"
                  hint="Choose the parent cohort. Annual periods and semester sessions belong to this year."
                >
                  <select
                    value={selectedYearId}
                    onChange={(event) => {
                      setSelectedYearId(event.target.value);
                      setSelectedPeriodId('');
                    }}
                    className={inputClass}
                  >
                    <option value="">Select academic year</option>

                    {academicYears.map((year) => (
                      <option key={year.id} value={year.id}>
                        {year.name}
                      </option>
                    ))}
                  </select>
                </Field>

                {!academicYears.length && (
                  <p className="mt-4 text-sm text-amber-600">
                    No academic years found. Create one to begin.
                  </p>
                )}

                {selectedYear && (
                  <div className="mt-5 grid gap-4 border-t border-[var(--border-color)] pt-5 sm:grid-cols-3">
                    <div>
                      <p className="text-xs text-slate-500">Academic Year</p>
                      <p className="mt-1 font-semibold">{selectedYear.name}</p>
                    </div>

                    <div>
                      <p className="text-xs text-slate-500">Duration</p>
                      <p className="mt-1 font-semibold">
                        {formatDate(selectedYear.start_date)} – {formatDate(selectedYear.end_date)}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs text-slate-500">Status</p>
                      <div className="mt-1">
                        <StatusBadge status={selectedYear.status} />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {selectedYear && (
                <div className="space-y-3">
                  <div>
                    <h3 className="font-bold">Annual Periods</h3>
                    <p className="mt-1 text-sm text-slate-500">
                      Annual periods belonging to {selectedYear.name}.
                    </p>
                  </div>

                  {periods.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-[var(--border-color)] bg-[var(--card-bg)] p-10 text-center">
                      <h3 className="font-semibold">
                        No annual periods created
                      </h3>

                      <p className="mt-2 text-sm text-slate-500">
                        Add periods such as 2023-24, 2024-25, 2025-26 and 2026-27.
                      </p>

                      <button
                        type="button"
                        onClick={openPeriodForm}
                        className="mt-4 rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white"
                      >
                        Create First Period
                      </button>
                    </div>
                  ) : (
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                      {periods.map((period) => (
                        <button
                          key={period.id}
                          type="button"
                          onClick={() => setSelectedPeriodId(period.id)}
                          className={`rounded-2xl border p-5 text-left transition ${
                            selectedPeriodId === period.id
                              ? 'border-cyan-500 bg-cyan-500/5 ring-1 ring-cyan-500/30'
                              : 'border-[var(--border-color)] bg-[var(--card-bg)]'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="text-lg font-bold">{period.name}</p>
                              <p className="mt-1 text-xs text-slate-500">
                                Annual Period
                              </p>
                            </div>

                            <StatusBadge status={period.status} />
                          </div>

                          <p className="mt-5 text-sm text-slate-500">
                            {formatDate(period.start_date)} – {formatDate(period.end_date)}
                          </p>

                          {selectedPeriodId === period.id && (
                            <p className="mt-3 text-xs font-semibold text-cyan-600">
                              Selected
                            </p>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {selectedPeriod && (
                <div className="rounded-2xl border border-cyan-500/30 bg-cyan-500/5 p-5">
                  <p className="text-xs font-semibold uppercase tracking-wider text-cyan-600">
                    Selected Annual Period
                  </p>

                  <p className="mt-2 text-xl font-bold">
                    {selectedPeriod.name}
                  </p>

                  <p className="mt-1 text-sm text-slate-500">
                    {formatDate(selectedPeriod.start_date)} – {formatDate(selectedPeriod.end_date)}
                  </p>

                  <button
                    type="button"
                    onClick={openSessionForm}
                    className="mt-4 rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700"
                  >
                    + Create Semester Session
                  </button>
                </div>
              )}
            </section>
          )}

          {/* ==================================================
              SEMESTER SESSIONS
          ================================================== */}

          {activeTab === 'sessions' && (
            <section className="space-y-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-lg font-bold">Semester Sessions</h2>

                  <p className="mt-1 text-sm text-slate-500">
                    View semester sessions and their generated batches.
                  </p>
                </div>

                <select
                  value={sessionYearFilter}
                  onChange={(event) => setSessionYearFilter(event.target.value)}
                  className={`${inputClass} sm:max-w-xs`}
                >
                  <option value="all">All Academic Years</option>

                  {academicYears.map((year) => (
                    <option key={year.id} value={year.id}>
                      {year.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="overflow-hidden rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)]">
                {filteredSessions.length === 0 ? (
                  <div className="p-12 text-center">
                    <h3 className="font-semibold">
                      No semester sessions found
                    </h3>

                    <p className="mt-2 text-sm text-slate-500">
                      Create a session under an annual period.
                    </p>

                    <button
                      type="button"
                      onClick={() => setActiveTab('structure')}
                      className="mt-4 rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white"
                    >
                      Go to Academic Structure
                    </button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[950px] text-left text-sm">
                      <thead className="border-b border-[var(--border-color)] bg-black/[0.025] dark:bg-white/[0.025]">
                        <tr className="text-xs uppercase tracking-wider text-slate-500">
                          <th className="px-5 py-4">Semester</th>
                          <th className="px-5 py-4">Academic Year</th>
                          <th className="px-5 py-4">Annual Period</th>
                          <th className="px-5 py-4">Batch</th>
                          <th className="px-5 py-4">Start Date</th>
                          <th className="px-5 py-4">End Date</th>
                          <th className="px-5 py-4">Status</th>
                        </tr>
                      </thead>

                      <tbody>
                        {filteredSessions.map((session) => (
                          <tr
                            key={session.id}
                            className="border-b border-[var(--border-color)] last:border-0 hover:bg-black/[0.02] dark:hover:bg-white/[0.02]"
                          >
                            <td className="px-5 py-4 font-semibold">
                              Semester {session.semester_number}
                            </td>

                            <td className="px-5 py-4">
                              {getYearName(session.academic_year_id)}
                            </td>

                            <td className="px-5 py-4">
                              {getPeriodName(session.academic_period_id)}
                            </td>

                            <td className="px-5 py-4">
                              {getBatchName(session.batch_id)}
                            </td>

                            <td className="px-5 py-4 text-slate-500">
                              {formatDate(session.start_date)}
                            </td>

                            <td className="px-5 py-4 text-slate-500">
                              {formatDate(session.end_date)}
                            </td>

                            <td className="px-5 py-4">
                              <StatusBadge status={session.status} />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-3 text-xs text-slate-500">
                <span>Planned: {plannedSessions}</span>
                <span>Active: {activeSessions}</span>
                <span>Completed: {completedSessions}</span>
                <span>Cancelled: {cancelledSessions}</span>
              </div>
            </section>
          )}

          {/* ==================================================
              BATCH-WISE SECTION MANAGEMENT
          ================================================== */}

          {activeTab === 'sections' && (
            <section className="space-y-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <h2 className="text-lg font-bold">Batch-wise Sections</h2>

                  <p className="mt-1 text-sm text-slate-500">
                    Manage sections independently for each batch.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={openCreateSectionForm}
                  disabled={!selectedBatchId}
                  className="rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  + Create Section
                </button>
              </div>

              <div className="rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-5">
                <Field
                  label="Select Batch"
                  hint="Sections belong to a batch, not to an individual semester."
                >
                  <select
                    value={selectedBatchId}
                    onChange={(event) => setSelectedBatchId(event.target.value)}
                    className={inputClass}
                  >
                    <option value="">Select a batch</option>

                    {batches.map((batch) => (
                      <option key={batch.id} value={batch.id}>
                        {batch.name}
                      </option>
                    ))}
                  </select>
                </Field>

                {selectedBatch && (
                  <div className="mt-4 border-t border-[var(--border-color)] pt-4">
                    <p className="text-xs text-slate-500">Selected Batch</p>
                    <p className="mt-1 font-semibold">{selectedBatch.name}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {batchSections.length} section(s) configured
                    </p>
                  </div>
                )}
              </div>

              {!batches.length ? (
                <div className="rounded-2xl border border-dashed border-[var(--border-color)] p-10 text-center">
                  <h3 className="font-semibold">No batches available</h3>
                  <p className="mt-2 text-sm text-slate-500">
                    Create an academic session first. The backend will resolve its batch.
                  </p>
                </div>
              ) : !selectedBatchId ? (
                <div className="rounded-2xl border border-dashed border-[var(--border-color)] p-10 text-center text-sm text-slate-500">
                  Select a batch to view its sections.
                </div>
              ) : batchSections.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[var(--border-color)] p-10 text-center">
                  <h3 className="font-semibold">
                    No sections in this batch
                  </h3>

                  <p className="mt-2 text-sm text-slate-500">
                    Create the first section for {selectedBatch?.name}.
                  </p>

                  <button
                    type="button"
                    onClick={openCreateSectionForm}
                    className="mt-4 rounded-xl bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white"
                  >
                    Create First Section
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  {batchSections.map((section) => (
                    <div
                      key={section.id}
                      className="rounded-2xl border border-[var(--border-color)] bg-[var(--card-bg)] p-5"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h3 className="text-lg font-bold">
                            {section.name}
                          </h3>

                          <p className="mt-1 text-xs text-slate-500">
                            {selectedBatch?.name}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => openEditSectionForm(section)}
                          className="rounded-lg border border-[var(--border-color)] px-3 py-1.5 text-xs font-semibold hover:bg-black/5 dark:hover:bg-white/5"
                        >
                          Edit
                        </button>
                      </div>

                      <div className="mt-5 border-t border-[var(--border-color)] pt-4">
                        <p className="text-xs text-slate-500">
                          Informational Capacity
                        </p>

                        <p className="mt-1 text-2xl font-bold">
                          {section.capacity_informational}
                          <span className="ml-1 text-xs font-normal text-slate-500">
                            students
                          </span>
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}
        </>
      )}

      {/* ======================================================
          CREATE ACADEMIC YEAR MODAL
      ====================================================== */}

      {showYearForm && (
        <Modal
          title="Create Academic Year"
          description="Create the parent cohort for your institution."
          onClose={closeForms}
          submitting={submitting}
        >
          <form onSubmit={handleCreateYear} className="space-y-5">
            {formError && <FormError message={formError} />}

            <InfoBox title="What is an Academic Year?">
              A parent academic year represents the complete duration of a
              student cohort. For example, a four-year B.Tech cohort can use
              2023-27. Annual periods and semester sessions are created inside it.
            </InfoBox>

            <Field
              label="Academic Year Name *"
              hint="Enter a unique cohort name."
              example="2023-27"
            >
              <input
                required
                maxLength={20}
                placeholder="YYYY-YY or YYYY-YYYY"
                value={yearForm.name}
                onChange={(event) =>
                  setYearForm({
                    ...yearForm,
                    name: event.target.value,
                  })
                }
                className={inputClass}
              />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                label="Start Date *"
                example="2023-06-17"
              >
                <input
                  required
                  type="date"
                  value={yearForm.start_date}
                  onChange={(event) =>
                    setYearForm({
                      ...yearForm,
                      start_date: event.target.value,
                    })
                  }
                  className={inputClass}
                />
              </Field>

              <Field
                label="End Date *"
                example="2027-07-31"
              >
                <input
                  required
                  type="date"
                  min={yearForm.start_date || undefined}
                  value={yearForm.end_date}
                  onChange={(event) =>
                    setYearForm({
                      ...yearForm,
                      end_date: event.target.value,
                    })
                  }
                  className={inputClass}
                />
              </Field>
            </div>

            <Field label="Status *">
              <select
                value={yearForm.status}
                onChange={(event) =>
                  setYearForm({
                    ...yearForm,
                    status: event.target.value as AcademicYearStatus,
                  })
                }
                className={inputClass}
              >
                <option value="planned">Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
              </select>
            </Field>

            <ModalActions
              onCancel={closeForms}
              submitting={submitting}
              submitLabel="Save Academic Year"
            />
          </form>
        </Modal>
      )}

      {/* ======================================================
          CREATE ANNUAL PERIOD MODAL
      ====================================================== */}

      {showPeriodForm && selectedYear && (
        <Modal
          title="Create Annual Period"
          description={`Add one academic period inside ${selectedYear.name}.`}
          onClose={closeForms}
          submitting={submitting}
        >
          <form onSubmit={handleCreatePeriod} className="space-y-5">
            {formError && <FormError message={formError} />}

            <InfoBox title="Annual Period Structure">
              For a four-year B.Tech cohort, create four chronological
              annual periods. Each period contains two semesters.
              <br />
              <br />
              2023-24 → Semesters 1 and 2
              <br />
              2024-25 → Semesters 3 and 4
              <br />
              2025-26 → Semesters 5 and 6
              <br />
              2026-27 → Semesters 7 and 8
            </InfoBox>

            <div className="rounded-xl bg-black/[0.03] p-3 text-sm dark:bg-white/[0.04]">
              <span className="text-slate-500">Parent academic year:</span>
              <strong className="ml-2">{selectedYear.name}</strong>
            </div>

            <Field label="Annual Period Name *">
              <input
                required
                maxLength={20}
                placeholder="Enter annual period name"
                value={periodForm.name}
                onChange={(event) =>
                  setPeriodForm({
                    ...periodForm,
                    name: event.target.value,
                  })
                }
                className={inputClass}
              />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Period Start Date *">
                <input
                  required
                  type="date"
                  min={selectedYear.start_date}
                  max={selectedYear.end_date}
                  value={periodForm.start_date}
                  onChange={(event) =>
                    setPeriodForm({
                      ...periodForm,
                      start_date: event.target.value,
                    })
                  }
                  className={inputClass}
                />
              </Field>

              <Field label="Period End Date *">
                <input
                  required
                  type="date"
                  min={periodForm.start_date || selectedYear.start_date}
                  max={selectedYear.end_date}
                  value={periodForm.end_date}
                  onChange={(event) =>
                    setPeriodForm({
                      ...periodForm,
                      end_date: event.target.value,
                    })
                  }
                  className={inputClass}
                />
              </Field>
            </div>

            <Field label="Status *">
              <select
                value={periodForm.status}
                onChange={(event) =>
                  setPeriodForm({
                    ...periodForm,
                    status: event.target.value as AcademicYearStatus,
                  })
                }
                className={inputClass}
              >
                <option value="planned">Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
              </select>
            </Field>

            <ModalActions
              onCancel={closeForms}
              submitting={submitting}
              submitLabel="Save Annual Period"
            />
          </form>
        </Modal>
      )}

      {/* ======================================================
          CREATE SEMESTER SESSION MODAL
      ====================================================== */}

      {showSessionForm && (
        <Modal
          title="Create Semester Session"
          description="Select the department and academic period. The backend resolves the programme and batch."
          onClose={closeForms}
          submitting={submitting}
        >
          <form onSubmit={handleCreateSession} className="space-y-5">
            {formError && <FormError message={formError} />}

            <InfoBox title="Automatic Batch Generation">
              You do not need to create or select a batch here.
              The backend finds the department's default B.Tech programme
              and creates or reuses its batch using the selected academic year.
            </InfoBox>

            <Field label="Department *" example="CSE AIML">
              <select
                required
                value={sessionForm.department_id}
                onChange={(event) =>
                  setSessionForm({
                    ...sessionForm,
                    department_id: event.target.value,
                  })
                }
                className={inputClass}
              >
                <option value="">Select department</option>

                {departments
                  .filter((department) => department.is_active !== false)
                  .map((department) => (
                    <option key={department.id} value={department.id}>
                      {department.name} ({department.code})
                    </option>
                  ))}
              </select>
            </Field>

            <Field label="Academic Year *" example="2023-27">
              <select
                required
                value={sessionForm.academic_year_id}
                onChange={(event) => {
                  const yearId = event.target.value;

                  setSessionForm({
                    ...sessionForm,
                    academic_year_id: yearId,
                    academic_period_id: '',
                    semester_number: '',
                    start_date: '',
                    end_date: '',
                  });

                  setSelectedYearId(yearId);
                }}
                className={inputClass}
              >
                <option value="">Select academic year</option>

                {academicYears.map((year) => (
                  <option key={year.id} value={year.id}>
                    {year.name}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Annual Period *" example="2023-24">
              <select
                required
                disabled={!sessionForm.academic_year_id}
                value={sessionForm.academic_period_id}
                onChange={(event) =>
                  setSessionForm({
                    ...sessionForm,
                    academic_period_id: event.target.value,
                    semester_number: '',
                    start_date: '',
                    end_date: '',
                  })
                }
                className={inputClass}
              >
                <option value="">Select annual period</option>

                {periods.map((period) => (
                  <option key={period.id} value={period.id}>
                    {period.name}
                  </option>
                ))}
              </select>

              {!periods.length && sessionForm.academic_year_id && (
                <p className="mt-2 text-xs text-amber-600">
                  No annual periods found. Create the annual periods first.
                </p>
              )}
            </Field>

            {batchPreview && (
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                  Automatically resolved batch
                </p>

                <p className="mt-2 text-lg font-bold">{batchPreview}</p>

                <p className="mt-1 text-xs text-slate-500">
                  The backend creates or reuses this batch when the session is saved.
                </p>
              </div>
            )}

            <Field label="Semester Number *">
              <select
                required
                disabled={!sessionForm.academic_period_id}
                value={sessionForm.semester_number}
                onChange={(event) =>
                  setSessionForm({
                    ...sessionForm,
                    semester_number: event.target.value,
                  })
                }
                className={inputClass}
              >
                <option value="">Select semester</option>

                {availableSemesters.map((semester) => (
                  <option key={semester} value={semester}>
                    Semester {semester}
                  </option>
                ))}
              </select>

              {sessionPeriodIndex >= 0 && (
                <p className="mt-2 text-xs text-cyan-600">
                  This period corresponds to semesters {availableSemesters[0]} and {availableSemesters[1]}.
                </p>
              )}
            </Field>

            <Field label="Session Status *">
              <select
                value={sessionForm.status}
                onChange={(event) =>
                  setSessionForm({
                    ...sessionForm,
                    status: event.target.value as AcademicSessionStatus,
                  })
                }
                className={inputClass}
              >
                <option value="planned">Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Semester Start Date *">
                <input
                  required
                  type="date"
                  disabled={!sessionPeriod}
                  min={sessionPeriod?.start_date}
                  max={sessionPeriod?.end_date}
                  value={sessionForm.start_date}
                  onChange={(event) =>
                    setSessionForm({
                      ...sessionForm,
                      start_date: event.target.value,
                      end_date: '',
                    })
                  }
                  className={inputClass}
                />
              </Field>

              <Field label="Semester End Date *">
                <input
                  required
                  type="date"
                  disabled={!sessionPeriod}
                  min={sessionForm.start_date || sessionPeriod?.start_date}
                  max={sessionPeriod?.end_date}
                  value={sessionForm.end_date}
                  onChange={(event) =>
                    setSessionForm({
                      ...sessionForm,
                      end_date: event.target.value,
                    })
                  }
                  className={inputClass}
                />
              </Field>
            </div>

            <ModalActions
              onCancel={closeForms}
              submitting={submitting}
              submitLabel="Create Semester Session"
            />
          </form>
        </Modal>
      )}

      {/* ======================================================
          CREATE / EDIT SECTION MODAL
      ====================================================== */}

      {showSectionForm && (
        <Modal
          title={editingSection ? 'Edit Section' : 'Create Section'}
          description={
            editingSection
              ? 'Update the section name or informational capacity.'
              : `Create a section under ${selectedBatch?.name ?? 'the selected batch'}.`
          }
          onClose={closeSectionForm}
          submitting={sectionSubmitting}
        >
          <form onSubmit={handleSaveSection} className="space-y-5">
            {sectionError && <FormError message={sectionError} />}

            <InfoBox title="Batch-wise Section Management">
              A section belongs to a batch, not to an individual semester.
              The same section can be used across the batch's academic sessions.
            </InfoBox>

            <Field label="Section Name *" example="A">
              <input
                required
                maxLength={50}
                placeholder="Enter section name"
                value={sectionForm.name}
                onChange={(event) =>
                  setSectionForm((previous) => ({
                    ...previous,
                    name: event.target.value,
                  }))
                }
                className={inputClass}
              />
            </Field>

            <Field
              label="Informational Capacity *"
              hint="This is informational only. It does not enforce an enrollment limit."
            >
              <input
                required
                type="number"
                min={1}
                step={1}
                value={sectionForm.capacity_informational}
                onChange={(event) =>
                  setSectionForm((previous) => ({
                    ...previous,
                    capacity_informational: event.target.value,
                  }))
                }
                className={inputClass}
              />
            </Field>

            <ModalActions
              onCancel={closeSectionForm}
              submitting={sectionSubmitting}
              submitLabel={
                editingSection ? 'Update Section' : 'Create Section'
              }
            />
          </form>
        </Modal>
      )}
    </div>
  );
}
