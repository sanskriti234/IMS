
'use client';

import { useCallback, useEffect, useState } from 'react';
import { AdminNavbar } from '@/components/navigation/AdminNavbar';
import {
  Users,
  Plus,
  Mail,
  BookOpen,
  Search,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  GraduationCap,
} from 'lucide-react';

import {
  facultyApi,
  institutionApi,
  type Faculty,
  type Department,
} from '@/lib/api';
import { FacultyAssignments } from '@/components/admin/FacultyAssignments';

type FacultyTab = 'directory' | 'add' | 'assignments';

interface FacultyForm {
  full_name: string;
  email: string;
  employee_code: string;
  designation: string;
  department_id: string;
}

const initialForm: FacultyForm = {
  full_name: '',
  email: '',
  employee_code: '',
  designation: 'Assistant Professor',
  department_id: '',
};

export default function FacultyPage() {
  const [activeTab, setActiveTab] = useState<FacultyTab>('directory');

  const [faculty, setFaculty] = useState<Faculty[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);

  const [form, setForm] = useState<FacultyForm>(initialForm);

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');

  const loadFaculty = useCallback(async () => {
    try {
      setLoading(true);
      setError('');

      const data = await facultyApi.getFaculty();
      setFaculty(data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to load faculty directory.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  const loadDepartments = useCallback(async () => {
    try {
      const data = await institutionApi.getDepartments();

      setDepartments(data.filter((department) => department.is_active !== false));
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to load departments.'
      );
    }
  }, []);

  useEffect(() => {
    void loadFaculty();
    void loadDepartments();
  }, [loadFaculty, loadDepartments]);

  const updateField = (
    field: keyof FacultyForm,
    value: string
  ) => {
    setForm((previous) => ({
      ...previous,
      [field]: value,
    }));
  };

  const handleCreateFaculty = async (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();

    setError('');
    setSuccess('');

    if (!form.department_id) {
      setError('Please select a department.');
      return;
    }

    try {
      setSubmitting(true);

      const payload = {
        full_name: form.full_name.trim(),
        email: form.email.trim().toLowerCase(),
        employee_code: form.employee_code.trim().toUpperCase(),
        designation: form.designation,
        department_id: form.department_id,
      };

      const createdFaculty = await facultyApi.createFaculty(payload);

      setFaculty((previous) => [
        createdFaculty,
        ...previous,
      ]);

      setForm(initialForm);
      setSuccess(
        `Faculty account created successfully for ${createdFaculty.full_name}. Credentials email has been queued for delivery.`
      );

      setActiveTab('directory');
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Faculty registration failed.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  const filteredFaculty = faculty.filter((member) => {
    const query = search.toLowerCase();

    return (
      member.full_name.toLowerCase().includes(query) ||
      member.email.toLowerCase().includes(query) ||
      member.employee_code.toLowerCase().includes(query) ||
      member.designation.toLowerCase().includes(query)
    );
  });

  const getDepartmentName = (departmentId: string) => {
    return (
      departments.find((department) => department.id === departmentId)?.name
      ?? 'Department unavailable'
    );
  };

  return (
    <div className="min-h-screen bg-[var(--bg-main)] text-[var(--text-main)] font-sans">
      <AdminNavbar />

      <main className="max-w-7xl mx-auto px-6 py-8 space-y-6">

        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[var(--border-color)]">
          <div>
            <h1 className="font-display text-3xl font-bold">
              Department Faculty
            </h1>

            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Manage faculty accounts, institutional details and assignments.
            </p>
          </div>

          <button
            onClick={() => {
              setError('');
              setSuccess('');
              setActiveTab('add');
            }}
            className="px-4 py-2 rounded-xl bg-[#176B52] hover:bg-[#125440] text-white text-xs font-medium transition-all shadow flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Add Department Faculty
          </button>
        </div>

        {/* Notifications */}
        {error && (
          <div className="flex items-start gap-3 p-4 rounded-xl border border-rose-300 bg-rose-50 dark:bg-rose-950/20 dark:border-rose-900 text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="flex items-start gap-3 p-4 rounded-xl border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/20 dark:border-emerald-900 text-emerald-700 dark:text-emerald-300">
            <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm">{success}</p>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-6 border-b border-[var(--border-color)] overflow-x-auto">
          <button
            onClick={() => {
              setError('');
              setSuccess('');
              setActiveTab('directory');
            }}
            className={`pb-3 px-1 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'directory'
                ? 'border-[#176B52] text-[#176B52]'
                : 'border-transparent text-slate-500'
            }`}
          >
            Faculty Directory
          </button>

          <button
            onClick={() => {
              setError('');
              setSuccess('');
              setActiveTab('add');
            }}
            className={`pb-3 px-1 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'add'
                ? 'border-[#176B52] text-[#176B52]'
                : 'border-transparent text-slate-500'
            }`}
          >
            Add New Faculty
          </button>

          <button
            onClick={() => {
              setError('');
              setSuccess('');
              setActiveTab('assignments');
            }}
            className={`pb-3 px-1 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'assignments'
                ? 'border-[#176B52] text-[#176B52]'
                : 'border-transparent text-slate-500'
            }`}
          >
            Assignments
          </button>
        </div>

        {/* Faculty Directory */}
        {activeTab === 'directory' && (
          <section className="space-y-5">

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)]">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-slate-500">
                    Total Faculty
                  </p>
                  <Users className="w-5 h-5 text-[#176B52]" />
                </div>
                <h2 className="text-3xl font-bold mt-2">
                  {faculty.length}
                </h2>
              </div>

              <div className="p-5 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)]">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-slate-500">
                    Departments Represented
                  </p>
                  <GraduationCap className="w-5 h-5 text-[#176B52]" />
                </div>
                <h2 className="text-3xl font-bold mt-2">
                  {new Set(faculty.map((item) => item.department_id)).size}
                </h2>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-between">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search faculty by name, email or employee code..."
                  className="w-full pl-10 pr-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-sm outline-none focus:border-[#176B52]"
                />
              </div>

              <button
                onClick={() => void loadFaculty()}
                disabled={loading}
                className="px-4 py-3 rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] text-sm flex items-center justify-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
            </div>

            {loading ? (
              <div className="py-16 text-center text-sm text-slate-500">
                Loading faculty directory...
              </div>
            ) : filteredFaculty.length === 0 ? (
              <div className="py-16 text-center rounded-2xl border border-dashed border-[var(--border-color)]">
                <Users className="w-10 h-10 mx-auto text-slate-400 mb-3" />
                <h3 className="font-semibold">
                  No faculty records found
                </h3>
                <p className="text-sm text-slate-500 mt-1">
                  Add a faculty member or change your search.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {filteredFaculty.map((member) => (
                  <article
                    key={member.id}
                    className="p-6 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm space-y-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full bg-[#176B52]/10 text-[#176B52] font-bold flex items-center justify-center uppercase">
                        {member.full_name.charAt(0)}
                      </div>

                      <div className="min-w-0">
                        <h3 className="font-bold text-sm truncate">
                          {member.full_name}
                        </h3>
                        <p className="text-xs text-slate-500">
                          {member.designation}
                        </p>
                      </div>
                    </div>

                    <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 pt-3 border-t border-[var(--border-color)]">
                      <div className="flex items-center gap-2 break-all">
                        <Mail className="w-4 h-4 shrink-0" />
                        {member.email}
                      </div>

                      <div className="flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 shrink-0" />
                        {getDepartmentName(member.department_id)}
                      </div>

                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 shrink-0" />
                        Employee Code: {member.employee_code}
                      </div>
                    </div>

                    <div className="pt-2">
                      <span className="inline-flex px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                        Faculty Account
                      </span>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
        )}

        {/* Add Faculty */}
        {activeTab === 'add' && (
          <section className="max-w-2xl mx-auto">
            <form
              onSubmit={handleCreateFaculty}
              className="p-7 md:p-8 rounded-2xl bg-[var(--card-bg)] border border-[var(--border-color)] shadow-sm space-y-6"
            >
              <div>
                <h2 className="font-display font-bold text-xl">
                  Register New Faculty
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Create a faculty account and send login credentials to their institutional email.
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold">
                  Full Name *
                </label>
                <input
                  required
                  minLength={2}
                  maxLength={255}
                  value={form.full_name}
                  onChange={(event) =>
                    updateField('full_name', event.target.value)
                  }
                  placeholder="Enter faculty full name"
                  className="w-full p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] text-sm outline-none focus:border-[#176B52]"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold">
                  Institutional Email *
                </label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(event) =>
                    updateField('email', event.target.value)
                  }
                  placeholder="faculty@institution.edu"
                  className="w-full p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] text-sm outline-none focus:border-[#176B52]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold">
                    Employee Code *
                  </label>
                  <input
                    required
                    maxLength={50}
                    value={form.employee_code}
                    onChange={(event) =>
                      updateField('employee_code', event.target.value)
                    }
                    placeholder="e.g. FAC001"
                    className="w-full p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] text-sm outline-none focus:border-[#176B52]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold">
                    Designation *
                  </label>
                  <select
                    required
                    value={form.designation}
                    onChange={(event) =>
                      updateField('designation', event.target.value)
                    }
                    className="w-full p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] text-sm font-medium outline-none focus:border-[#176B52]"
                  >
                    <option value="Assistant Professor">
                      Assistant Professor
                    </option>
                    <option value="Associate Professor">
                      Associate Professor
                    </option>
                    <option value="Professor">
                      Professor
                    </option>
                    <option value="Head of Department">
                      Head of Department
                    </option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-semibold">
                  Department *
                </label>
                <select
                  required
                  value={form.department_id}
                  onChange={(event) =>
                    updateField('department_id', event.target.value)
                  }
                  className="w-full p-3 rounded-xl border border-[var(--border-color)] bg-[var(--bg-main)] text-sm font-medium outline-none focus:border-[#176B52]"
                >
                  <option value="">Select department</option>

                  {departments.map((department) => (
                    <option key={department.id} value={department.id}>
                      {department.name} ({department.code})
                    </option>
                  ))}
                </select>

                {departments.length === 0 && (
                  <p className="text-xs text-rose-500">
                    No departments available. Check the institution API.
                  </p>
                )}
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900">
                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-[#176B52] shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-[#176B52] dark:text-emerald-300">
                      Automatic Login Credentials
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                      CoreSight will generate a temporary password, create the faculty login account and send the credentials to the registered email.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setForm(initialForm);
                    setError('');
                  }}
                  disabled={submitting}
                  className="flex-1 py-3 rounded-xl border border-[var(--border-color)] text-sm font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50"
                >
                  Reset Form
                </button>

                <button
                  type="submit"
                  disabled={submitting || departments.length === 0}
                  className="flex-1 py-3 bg-[#176B52] text-white font-semibold rounded-xl hover:bg-[#125440] transition-colors disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Creating Account...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      Create Faculty Account
                    </>
                  )}
                </button>
              </div>
            </form>
          </section>
        )}

        {/* Assignments */}
          {activeTab === 'assignments' && (
            <FacultyAssignments />
          )}

      </main>
    </div>
  );
}
